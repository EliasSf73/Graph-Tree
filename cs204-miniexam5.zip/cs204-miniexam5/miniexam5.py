"""
MiniExam #5 Skeleton code

Write additional codes below if necessary
"""

def problem1(links):
    redundant_link_indices = []
    """
    TODO: compute redundant links from given links
    """
    return redundant_link_indices

def problem2(new_links, max_traffic):
    """
    TODO: compute whether given links never exceeds the max traffic
    """
    return True

#######################################
# DO NOT edit below this line!        #
#   though you are welcome to read :) #
#######################################

def simulate_problem2(links, max_traffic):
    result = []
    redundant_link_indices = problem1(links)
    for link_index in redundant_link_indices:
        new_links = links.copy()
        new_links.pop(link_index)
        if problem2(new_links, max_traffic):
            result.append(link_index) 
    return result

if __name__ == "__main__":
    import sys
    sys.setrecursionlimit(3000)
    
    def readline():
        return sys.stdin.readline().strip()
    def read_links(n):
        return [tuple(int(x) for x in readline().split()) for _ in range(n)]

    # Help when no args given
    argc = len(sys.argv)
    if argc != 2 or sys.argv[1] not in ['1', '2']:
        print(f"usage: python {sys.argv[0]} PROBLEM_NUMBER", file=sys.stderr)
        exit(1)
    
    if sys.argv[1] == '1':
        # Problem 1
        n = int(readline().split()[0])
        links = read_links(n)
        result = problem1(links)
    else:
        # Problem 2
        n, max_traffic = (int(x) for x in readline().split())
        links = read_links(n)
        result = simulate_problem2(links, max_traffic)

    # Print result
    print(len(result))
    for link_index in result:
        print(link_index)
